/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/*
//netbeans generated code
package rsa;

//
// *
// * @author Lejun_Hu
// 
public class rsa {
    
}
*/
 
// code is taken from wesite:
// https://www.sanfoundry.com/java-program-implement-rsa-algorithm/

//package com.sanfoundry.setandstring;
package rsa;
 
import java.io.DataInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Random;
 
public class rsa
{
    private BigInteger p; //large prime number
    private BigInteger q; //large prime number
    private BigInteger N; //=P*Q
    private BigInteger phi; //=(p-1)*(q-1)
    private BigInteger e; //a number relative prime to phi, <e,N> is public key
    private BigInteger d; //multiplicative inverse of e mod phi, <d,N> is private key
    private int        bitlength = 1024;
    private Random     r; 
 
    //constructor without 
    public rsa()
    {
        r = new Random(); //this is a seed?
        //System.out.println("r: " + r);
        p = BigInteger.probablePrime(bitlength, r);
        //System.out.println("p: " + p);
        q = BigInteger.probablePrime(bitlength, r);
        //System.out.println("q: " + q);
        N = p.multiply(q);
        //System.out.println("N: " + N);
        phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
        //System.out.println("phi: " + phi);
        e = BigInteger.probablePrime(bitlength / 2, r); //look for greatest common divisor
        while (phi.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(phi) < 0)
        {
            e.add(BigInteger.ONE);
        }
        //System.out.println("e: " + e);
        d = e.modInverse(phi);
        //System.out.println("d: " + d);
    }
 
    public rsa(BigInteger e, BigInteger d, BigInteger N)
    {
        this.e = e;
        this.d = d;
        this.N = N;
        //this.p = p;
        //this.q = q;
        //this.phi = phi;
    }
 
    @SuppressWarnings("deprecation")
    public static void main(String[] args) throws IOException
    {
        //*
        //rsa rsa_object = new rsa(); //create rsa object
        
        ///*
        BigInteger fixed_e = new BigInteger("9936383505488703705432755438457817920456821234890313657300552132544935021288549881258052867284440758008369307396703105348543880951238801442240112015219921");
        BigInteger fixed_d = new BigInteger("1856179175637559125042834891932391444744859746418359328956617204251509627073070156985451476667212277042303242121015151324438148077559700030231393569239443719198428529832246793817156809211786968288278950719020501499369002620625394218050641022008054690699872129636861470291886647100244508002660924585014813045564718943513729982419865647494525800071116115814346843212580847271149774341465686492774181638496043491643109412429458988532736367480708385980709497799856202149614299107362180762187107865811786270527911979172047310836981510232406459223907530304164802790673878874453222699868333782762107020162267398248406904593");
        BigInteger fixed_n = new BigInteger("16244843174233802268866395503573922702831226904204381442474371848761394940169279051643729572430135700524278440065781460344940979434539935374622687397780115516626078058574798768622359679750584022518256490659382154246572365784168118655628386508260894524256428590427985692024550808496530737186536724035469503609215249019373024293083196533098995724446342087169424694408793591255049379258843434942303200523389786216368415553904116776743956433741509609434643587095003043036298021735218623056668505574140687694302089209654415301873921064044280071508913391244131091393902028044776913061952529984893956003165582369851448976181");
        rsa rsa_object = new rsa(fixed_e, fixed_d, fixed_n); //create rsa object
        System.out.println("e: " + rsa_object.e());
        //rsa_object.set_e(rsa_object.e());
        //System.out.println("e: " + rsa_object.e());
        
        //BigInteger fixed_d = new BigInteger("1856179175637559125042834891932391444744859746418359328956617204251509627073070156985451476667212277042303242121015151324438148077559700030231393569239443719198428529832246793817156809211786968288278950719020501499369002620625394218050641022008054690699872129636861470291886647100244508002660924585014813045564718943513729982419865647494525800071116115814346843212580847271149774341465686492774181638496043491643109412429458988532736367480708385980709497799856202149614299107362180762187107865811786270527911979172047310836981510232406459223907530304164802790673878874453222699868333782762107020162267398248406904593");
        System.out.println("d: " + rsa_object.d());
        //rsa_object.set_d(rsa_object.d());
        //System.out.println("d: " + rsa_object.d());

        //BigInteger fixed_n = new BigInteger("16244843174233802268866395503573922702831226904204381442474371848761394940169279051643729572430135700524278440065781460344940979434539935374622687397780115516626078058574798768622359679750584022518256490659382154246572365784168118655628386508260894524256428590427985692024550808496530737186536724035469503609215249019373024293083196533098995724446342087169424694408793591255049379258843434942303200523389786216368415553904116776743956433741509609434643587095003043036298021735218623056668505574140687694302089209654415301873921064044280071508913391244131091393902028044776913061952529984893956003165582369851448976181");
        System.out.println("n: " + rsa_object.n());
        //rsa_object.set_d(rsa_object.n());
        //System.out.println("n: " + rsa_object.n());
        //*/
        
        DataInputStream in = new DataInputStream(System.in);
        String teststring;
        System.out.println("Enter the plain text:");
        teststring = in.readLine(); //read in the line
        System.out.println("Encrypting String: " + teststring);
        System.out.println("String in Bytes: "
                + bytesToString(teststring.getBytes())); //convert byte array to string
        // encrypt
        byte[] encrypted = rsa_object.encrypt(teststring.getBytes()); // byte array
        // decrypt
        byte[] decrypted = rsa_object.decrypt(encrypted); // byte array
        System.out.println("Decrypting Bytes: " + bytesToString(decrypted)); // convert byte array to string of numbers
        System.out.println("Decrypted String: " + new String(decrypted));  // convert string of numbers to message
        

        //*/
    }
 
    public static String bytesToString(byte[] encrypted)
    {
        String test = "";
        for (byte b : encrypted)
        {
            test += Byte.toString(b);
        }
        return test;
        
    }
    
    public BigInteger e ()
    {
        return this.e;
    }
    
    public void set_e (BigInteger input_e)
    {
        this.e = input_e;
    }
    
    public BigInteger d ()
    {
        return this.d;
    }
    
    public void set_d (BigInteger input_d)
    {
        this.d = input_d;
    }
    
    public BigInteger n ()
    {
        return this.N;
    }
    
    public void set_n (BigInteger input_n)
    {
        this.N = input_n;
    }
 
    // Encrypt message, raise message to power e, mod by N
    public byte[] encrypt(byte[] message)
    {
        return (new BigInteger(message)).modPow(e, N).toByteArray();
    }
 
    // Decrypt message, raise message to power d, mod by N
    public byte[] decrypt(byte[] message)
    {
        return (new BigInteger(message)).modPow(d, N).toByteArray();
    }
    
    
    
}
